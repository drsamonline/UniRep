#!/usr/bin/env python3
"""Build the offline MateriaAI SQLite core from public-domain OCR editions.

The compiler intentionally uses only Python's standard library so it can be run
on a clean machine. Source OCR is cached, cleaned deterministically, and kept
out of git; the resulting SQLite file is the distributable offline artifact.
"""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import sys
import urllib.request
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "materia_ai_data"
RAW_DIR = OUT_DIR / "raw"
DB_PATH = OUT_DIR / "materia_ai_core.db"
REPORT_PATH = OUT_DIR / "materia_ai_core.validation.json"

SOURCES = [
    {
        "key": "boericke",
        "title": "Boericke's Pocket Manual of Homoeopathic Materia Medica",
        "edition": "8th edition",
        "url": "https://archive.org/download/in.ernet.dli.2015.125811/2015.125811.Pocket-Manual-Of-Homoeopathic-Materia-Medica-Ed8th_djvu.txt",
    },
    {
        "key": "kent",
        "title": "Kent's Repertory of the Homoeopathic Materia Medica",
        "edition": "electronic full-text edition",
        "url": "https://archive.org/download/b20416234_001/b20416234_001_djvu.txt",
    },
    {
        "key": "allen",
        "title": "Keynotes and Characteristics with Comparisons",
        "edition": "public-domain edition",
        "url": "https://archive.org/download/in.ernet.dli.2015.31637/2015.31637.Keynotes-And-Characteristics-With-Comparisons-Of-Some-Of-The-Leading-Remedies-Of-The-Materia-Medica_djvu.txt",
    },
    {
        "key": "boenninghausen",
        "title": "Boenninghausen's Therapeutic Pocket Book",
        "edition": "public-domain edition",
        "url": "https://archive.org/download/in.ernet.dli.2015.93043/2015.93043.Therapeutic-Pocket-book_djvu.txt",
    },
    {
        "key": "organon",
        "title": "Organon of Medicine",
        "edition": "5th and 6th editions",
        "url": "https://archive.org/download/in.ernet.dli.2015.31779/2015.31779.Organon-Of-Medicinefifth-And-Sixth-Edition_djvu.txt",
    },
]

# Common historical spellings/abbreviations. The canonical names are used as
# stable join keys while the original text remains unchanged in books_text.
ALIASES = {
    "acon": "Aconitum napellus",
    "acon.": "Aconitum napellus",
    "acon-n": "Aconitum napellus",
    "acon-n.": "Aconitum napellus",
    "aconitum": "Aconitum napellus",
    "ars": "Arsenicum album",
    "ars.": "Arsenicum album",
    "arsen": "Arsenicum album",
    "arsenicum": "Arsenicum album",
    "bell": "Belladonna",
    "bell.": "Belladonna",
    "belladonna": "Belladonna",
    "nux-v": "Nux vomica",
    "nux-v.": "Nux vomica",
    "nux vom": "Nux vomica",
    "nux vomica": "Nux vomica",
    "puls": "Pulsatilla",
    "puls.": "Pulsatilla",
    "pulsatilla": "Pulsatilla",
    "sulph": "Sulphur",
    "sulph.": "Sulphur",
    "sulphur": "Sulphur",
    "lyc": "Lycopodium clavatum",
    "lyc.": "Lycopodium clavatum",
    "lycopodium": "Lycopodium clavatum",
    "phos": "Phosphorus",
    "phos.": "Phosphorus",
    "phosphorus": "Phosphorus",
    "calc": "Calcarea carbonica",
    "calc.": "Calcarea carbonica",
    "calc carb": "Calcarea carbonica",
    "calcarea carb": "Calcarea carbonica",
    "ign": "Ignatia amara",
    "ign.": "Ignatia amara",
    "ignatia": "Ignatia amara",
}

RUBRIC_WORDS = {
    "mind", "head", "eye", "eyes", "ear", "ears", "nose", "face", "mouth",
    "throat", "chest", "stomach", "abdomen", "back", "extremities", "skin",
    "fever", "sleep", "generals", "respiration", "cough", "pain", "inflammation",
    "mental", "chill", "perspiration", "urinary", "rectum", "female", "male",
}


def fetch_source(source: dict) -> Path:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    path = RAW_DIR / f"{source['key']}.txt"
    if not path.exists() or path.stat().st_size < 1000:
        request = urllib.request.Request(source["url"], headers={"User-Agent": "MateriaAI-offline-builder/1.0"})
        with urllib.request.urlopen(request, timeout=120) as response, path.open("wb") as out:
            while chunk := response.read(1024 * 1024):
                out.write(chunk)
    return path


def clean_text(raw: str) -> str:
    text = raw.replace("\r\n", "\n").replace("\r", "\n").replace("\x0c", "\n")
    text = re.sub(r"-\n(?=[a-z])", "", text)
    text = re.sub(r"[ \t]+", " ", text)
    lines: list[str] = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            if lines and lines[-1] != "":
                lines.append("")
            continue
        if re.fullmatch(r"\d{1,4}", line):
            continue
        if re.search(r"Internet Archive|Digitized by|Full text of|OCR|www\.", line, re.I):
            continue
        if re.fullmatch(r"[-_=*]{3,}", line):
            continue
        lines.append(line)
    return "\n".join(lines).strip()


def paragraphs(cleaned: str) -> list[str]:
    blocks = [re.sub(r"\s+", " ", b).strip() for b in re.split(r"\n{2,}", cleaned)]
    return [b for b in blocks if len(b) >= 8]


def canonical_remedy(value: str) -> str:
    key = re.sub(r"[^a-z0-9 .-]", "", value.lower()).strip()
    return ALIASES.get(key, value.strip().title())


def extract_remedies(text: str) -> set[str]:
    found: set[str] = set(ALIASES.values())
    # Most materia medica OCR headings are short title-case or uppercase lines.
    for line in text.splitlines():
        value = line.strip(" .:-")
        if not (3 <= len(value) <= 60) or len(value.split()) > 7:
            continue
        if value.lower() in {"chapter", "contents", "introduction", "index"}:
            continue
        if re.search(r"\d", value) or value.endswith((",", ";")):
            continue
        if value.isupper() or re.match(r"^[A-Z][A-Za-z]+(?: [A-Za-z.-]+){0,5}$", value):
            words = value.lower().split()
            if any(word in ALIASES for word in words) or (value.isupper() and len(value) > 3):
                found.add(canonical_remedy(value))
    return {x for x in found if len(x) >= 3}


def chapter_title(source_key: str, block: str, index: int) -> str:
    if source_key == "organon":
        match = re.search(r"§\s*(\d+)", block)
        return f"Organon paragraph {match.group(1)}" if match else "Organon introductory text"
    if source_key == "kent":
        first = block.split(" ", 12)[0:8]
        candidate = " ".join(first)
        if candidate and len(candidate) < 80:
            return candidate.title()
    return f"{source_key.title()} section {index}"


def rubric_from_block(block: str, source_key: str, index: int) -> tuple[str, str | None]:
    first = block.split(". ", 1)[0].strip()
    words = first.lower().split()
    if any(word.strip(",:;") in RUBRIC_WORDS for word in words):
        name = first[:180]
    else:
        name = f"{source_key.title()} extracted rubric {index}"
    parent = name.split(" > ", 1)[0] if " > " in name else None
    return name, parent


def build() -> dict:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    source_rows: list[dict] = []
    all_blocks: list[tuple[dict, int, str]] = []
    for source in SOURCES:
        raw_path = fetch_source(source)
        raw = raw_path.read_text(encoding="utf-8", errors="replace")
        cleaned = clean_text(raw)
        blocks = paragraphs(cleaned)
        digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        source_rows.append({**source, "sha256": digest, "raw_bytes": len(raw.encode()), "cleaned_chars": len(cleaned), "blocks": len(blocks)})
        all_blocks.extend((source, i + 1, block) for i, block in enumerate(blocks))

    if DB_PATH.exists():
        DB_PATH.unlink()
    db = sqlite3.connect(DB_PATH)
    db.execute("PRAGMA journal_mode=DELETE")
    db.execute("PRAGMA page_size=4096")
    db.executescript(
        """
        CREATE TABLE remedies (
          remedy_id INTEGER PRIMARY KEY,
          canonical_name TEXT NOT NULL UNIQUE,
          normalized_name TEXT NOT NULL UNIQUE
        );
        CREATE TABLE chapters (
          chapter_id INTEGER PRIMARY KEY,
          book_key TEXT NOT NULL,
          title TEXT NOT NULL,
          edition TEXT NOT NULL,
          chapter_order INTEGER NOT NULL
        );
        CREATE TABLE rubrics (
          rubric_id INTEGER PRIMARY KEY,
          chapter_id INTEGER NOT NULL REFERENCES chapters(chapter_id),
          parent_rubric_id INTEGER REFERENCES rubrics(rubric_id),
          rubric_text TEXT NOT NULL,
          normalized_text TEXT NOT NULL UNIQUE
        );
        CREATE TABLE remedy_rubric_cross (
          remedy_id INTEGER NOT NULL REFERENCES remedies(remedy_id),
          rubric_id INTEGER NOT NULL REFERENCES rubrics(rubric_id),
          grade INTEGER NOT NULL CHECK (grade BETWEEN 1 AND 3),
          PRIMARY KEY (remedy_id, rubric_id)
        );
        CREATE VIRTUAL TABLE books_text USING fts5(
          book_key UNINDEXED, edition UNINDEXED, chapter_id UNINDEXED,
          source_locator UNINDEXED, paragraph_number UNINDEXED,
          content, tokenize='unicode61 remove_diacritics 2'
        );
        """
    )

    remedy_names = set()
    for source in SOURCES:
        raw_path = RAW_DIR / f"{source['key']}.txt"
        # Kent and the pocketbook contain many all-caps rubric lines; use
        # materia-medica headings for the canonical remedy catalogue and keep
        # the repertory text itself in FTS.
        if source["key"] in {"boericke", "allen"}:
            remedy_names.update(extract_remedies(clean_text(raw_path.read_text(encoding="utf-8", errors="replace"))))
    remedy_names = sorted(remedy_names, key=lambda x: (re.sub(r'[^a-z0-9]+', ' ', x.lower()).strip(), x))
    deduped_names = []
    seen_normalized = set()
    for name in remedy_names:
        normalized = re.sub(r'[^a-z0-9]+', ' ', name.lower()).strip()
        if normalized not in seen_normalized:
            seen_normalized.add(normalized)
            deduped_names.append(name)
    remedy_names = deduped_names
    remedy_id = {}
    for i, name in enumerate(remedy_names, 1):
        normalized = re.sub(r"[^a-z0-9]+", " ", name.lower()).strip()
        db.execute("INSERT INTO remedies VALUES (?, ?, ?)", (i, name, normalized))
        remedy_id[normalized] = i

    chapters: dict[str, list[int]] = defaultdict(list)
    next_chapter = 1
    for source in SOURCES:
        source_blocks = [(num, block) for src, num, block in all_blocks if src["key"] == source["key"]]
        if source["key"] == "organon":
            for order, (num, block) in enumerate(source_blocks, 1):
                match = re.search(r"§\s*(\d+)", block)
                if match:
                    title = f"Organon §{match.group(1)}"
                else:
                    title = "Organon introductory text"
                db.execute("INSERT INTO chapters VALUES (?, ?, ?, ?, ?)", (next_chapter, source["key"], title, source["edition"], order))
                chapters[source["key"]].append(next_chapter)
                next_chapter += 1
        else:
            db.execute("INSERT INTO chapters VALUES (?, ?, ?, ?, ?)", (next_chapter, source["key"], source["title"], source["edition"], 1))
            chapters[source["key"]].append(next_chapter)
            next_chapter += 1

    rubric_id: dict[str, int] = {}
    rubric_rows = []
    next_rubric = 1
    text_rows = 0
    known_aliases = sorted(
        ((alias, canonical_remedy(canonical)) for alias, canonical in ALIASES.items()),
        key=lambda item: len(item[0]),
        reverse=True,
    )
    alias_pattern = re.compile(r"(?<![a-z])(" + "|".join(re.escape(alias.rstrip(".")) for alias, _ in known_aliases) + r")\.?(?![a-z])", re.I)
    for source, number, block in all_blocks:
        chapter = chapters[source["key"]][number - 1] if source["key"] == "organon" and number <= len(chapters[source["key"]]) else chapters[source["key"]][0]
        db.execute("INSERT INTO books_text VALUES (?, ?, ?, ?, ?, ?)", (source["key"], source["edition"], chapter, source["url"], number, block))
        text_rows += 1
        rubric_text, parent_text = rubric_from_block(block, source["key"], number)
        normalized = re.sub(r"[^a-z0-9]+", " ", rubric_text.lower()).strip()
        if normalized not in rubric_id:
            rubric_id[normalized] = next_rubric
            parent_id = rubric_id.get(re.sub(r"[^a-z0-9]+", " ", parent_text.lower()).strip()) if parent_text else None
            db.execute("INSERT INTO rubrics VALUES (?, ?, ?, ?, ?)", (next_rubric, chapter, parent_id, rubric_text, normalized))
            next_rubric += 1
        current_rubric = rubric_id[normalized]
        lower_block = block.lower()
        matched = {canonical for match in alias_pattern.finditer(lower_block)
                   for alias, canonical in known_aliases if alias.rstrip(".").lower() == match.group(1).lower()}
        for canonical in matched:
            normalized_name = re.sub(r"[^a-z0-9]+", " ", canonical.lower()).strip()
            rid = remedy_id.get(normalized_name)
            if rid:
                grade = 3 if source["key"] in {"boericke", "allen"} else 2
                db.execute("INSERT OR IGNORE INTO remedy_rubric_cross VALUES (?, ?, ?)", (rid, current_rubric, grade))

    db.execute("CREATE INDEX idx_rubrics_chapter ON rubrics(chapter_id)")
    db.execute("CREATE INDEX idx_cross_rubric ON remedy_rubric_cross(rubric_id)")
    db.execute("ANALYZE")
    db.commit()
    integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
    counts = {
        "remedies": db.execute("SELECT COUNT(*) FROM remedies").fetchone()[0],
        "chapters": db.execute("SELECT COUNT(*) FROM chapters").fetchone()[0],
        "rubrics": db.execute("SELECT COUNT(*) FROM rubrics").fetchone()[0],
        "cross_links": db.execute("SELECT COUNT(*) FROM remedy_rubric_cross").fetchone()[0],
        "book_paragraphs": db.execute("SELECT COUNT(*) FROM books_text").fetchone()[0],
        "fts_rows": db.execute("SELECT COUNT(*) FROM books_text").fetchone()[0],
    }
    db.close()
    db_size = DB_PATH.stat().st_size
    report = {
        "database": DB_PATH.name,
        "schema": ["remedies", "chapters", "rubrics", "remedy_rubric_cross", "books_text (FTS5)"],
        "sources": source_rows,
        "counts": counts,
        "integrity_check": integrity,
        "size_bytes": db_size,
        "size_mb": round(db_size / 1024 / 1024, 3),
        "under_50mb": db_size < 50 * 1024 * 1024,
        "cleaning": ["normalized line endings", "dehyphenated OCR line breaks", "removed page-only and OCR artifact lines", "normalized whitespace"],
        "notes": "Source OCR and heuristically extracted rubric/remedy links retain provenance in books_text.source_locator. Clinical interpretation remains with the practitioner.",
    }
    REPORT_PATH.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return report


if __name__ == "__main__":
    try:
        result = build()
        print(json.dumps(result, indent=2, ensure_ascii=False))
    except Exception as exc:
        print(f"MateriaAI build failed: {exc}", file=sys.stderr)
        raise